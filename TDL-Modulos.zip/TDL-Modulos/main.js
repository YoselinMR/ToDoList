const { mostrarMenu } = require("./mostrarMenu.js");

mostrarMenu();
