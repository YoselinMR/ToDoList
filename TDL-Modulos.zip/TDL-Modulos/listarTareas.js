const prompt = require("./promp.js");
const { tareas } = require("./tareas.js");
const { mostrarDetalles } = require("./mostrarDetalles.js");

function listarTareas(filtro = "Todas") {
    // Asegurarse que filtro sea string para evitar errores con toLowerCase
    filtro = filtro || "Todas";

    let lista = [];

    for (let i = 0; i < tareas.length; i++) {
        if (filtro === "Todas" || tareas[i].estado === filtro) {
            lista.push(tareas[i]);
        }
    }

    if (lista.length === 0) {
        console.log(`\nNo hay tareas.`);
        return;
    }

    console.log("\nEstas son tus tareas:");

    for (let i = 0; i < lista.length; i++) {
        console.log(`[${i + 1}] ${lista[i].titulo}`);
    }

    let num = prompt("\nVer detalles (número) o 0 para volver: ");
    if (num === "0") return;

    let indice = parseInt(num, 10) - 1;

    if (!isNaN(indice) && indice >= 0 && indice < lista.length) {
        mostrarDetalles(lista[indice]);
    } else {
        console.log("Número inválido");
    }
}

module.exports = { listarTareas };
