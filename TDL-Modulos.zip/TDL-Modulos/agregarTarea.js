const prompt = require("./promp.js");
const { validarFecha } = require("./validarFecha.js");
const { tareas } = require("./tareas.js");

function agregarTarea() {
    console.log("\nCrea una nueva tarea:");

    let titulo = "";
    while (true) {
        titulo = prompt("1| Título: ").trim();
        if (titulo !== "") break;
        console.log("❌ El título no puede estar vacío.");
    }

    let descripcion = prompt("2| Descripción: ");

    let estado = "Pendiente";
    let estadoInput = prompt("3| Estado (P = Pendiente | E = En curso | T = Terminada): ").toUpperCase();
    if (estadoInput === "E") estado = "En curso";
    else if (estadoInput === "T") estado = "Terminada";

    let dificultad = "Baja";
    let dif = prompt("4| Dificultad (1 = Baja | 2 = Media | 3 = Alta): ");
    if (dif === "2") dificultad = "Media";
    else if (dif === "3") dificultad = "Alta";

    let vence = "";
    while (true) {
        vence = prompt("5. Vencimiento (dd/mm/yyyy, enter para dejar sin fecha): ");
        if (vence.trim() === "") {
            vence = "Sin fecha";
            break;
        } else if (validarFecha(vence)) {
            break;
        } else {
            console.log("❌ Fecha inválida. Intenta de nuevo.");
        }
    }

    const nuevaTarea = {
        titulo: titulo,
        descripcion: descripcion || "Sin descripción",
        estado: estado,
        dificultad: dificultad,
        vencimiento: vence,
        fechaCreacion: new Date().toLocaleString()
    };

    tareas.push(nuevaTarea);

    console.log("\n¡Tarea agregada!");
    prompt("\nPresiona cualquier tecla para continuar...");
}

module.exports = { agregarTarea };
