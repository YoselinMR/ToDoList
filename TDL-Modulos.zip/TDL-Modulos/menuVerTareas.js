const prompt = require("./promp.js");
const { listarTareas } = require("./listarTareas.js");

function menuVerTareas() {
    let op;
    do {
        console.log("\n VER TAREAS ");
        console.log("1| Pendientes");
        console.log("2| En curso");
        console.log("3| Terminadas");
        console.log("4| Todas");
        console.log("0| Volver");

        op = prompt("> ");

        switch (op) {
            case "1": listarTareas("Pendiente"); break;
            case "2": listarTareas("En curso"); break;
            case "3": listarTareas("Terminada"); break;
            case "4": listarTareas("Todas"); break;
            case "0": break;
            default: console.log("Opción inválida"); break;
        }
    } while (op !== "0");
}

module.exports = { menuVerTareas };
