const prompt = require("./promp.js");
const { tareas } = require("./tareas.js");
const { mostrarDetalles } = require("./mostrarDetalles.js");

function buscarTarea() {
    let clave = prompt("Introduce el título (o 0 para volver): ")
    if (clave === "0") return;

    let resultados = [];
    for (let i = 0; i < tareas.length; i++) {
        let titulo = tareas[i].titulo || '';
        if (titulo.toLowerCase().indexOf(clave.toLowerCase()) !== -1) {
            resultados.push(tareas[i]);
        }
    }

    if (resultados.length === 0) {
        console.log("\nNo se encontraron tareas.");
        prompt("\nPresiona una tecla para continuar...");
        return;
    }

    console.log("\nCoincidencias:\n");
    for (let i = 0; i < resultados.length; i++) {
        console.log(`[${i + 1}] ${resultados[i].titulo}`);
    }

    let num = prompt("\nVer detalles (número) o 0 para volver: ");
    if (num === "0") return;

    let indice = parseInt(num, 10) - 1;
    if (!isNaN(indice) && indice >= 0 && indice < resultados.length) {
        mostrarDetalles(resultados[indice]);
    } else {
        console.log("Número inválido");
    }
}

module.exports = { buscarTarea };
