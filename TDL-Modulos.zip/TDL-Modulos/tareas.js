let tareas = [];

module.exports = { tareas };
