const prompt = require("prompt-sync")({ sigint: true });
module.exports = prompt;
