const prompt = require("./promp.js");
const { menuVerTareas } = require("./menuVerTareas.js");
const { buscarTarea } = require("./buscarTarea.js");
const { agregarTarea } = require("./agregarTarea.js");

function mostrarMenu() {
    let opcion;
    do {
        console.log("\n MENU PRINCIPAL ");
        console.log("1| Ver tareas");
        console.log("2| Buscar tarea");
        console.log("3| Agregar tarea");
        console.log("0| Salir");

        opcion = prompt("> ");

        switch (opcion) {
            case "1":
                menuVerTareas();
                break;
            case "2":
                buscarTarea();
                break;
            case "3":
                agregarTarea();
                break;
            case "0":
                console.log("¡Hasta luego!");
                break;
            default:
                console.log("Opción inválida");
        }
    } while (opcion !== "0");
}

module.exports = { mostrarMenu };
